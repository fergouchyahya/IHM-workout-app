'use strict';

/* T4 autonome : les publications de démonstration ont leur propre stockage. */
window.Partages = {
  key:'ihm-prototype-1-t4',
  stage:'list',
  source:null,
  draft:null,
  activeId:null,
  editing:false,
  data:{items:[]},
  restore() {
    try {
      const value = window.Parcours.profiles[window.Parcours.state.identity]?.sharing || JSON.parse(localStorage.getItem(this.key) || 'null');
      if (value && Array.isArray(value.items)) {
        this.data = value;
        for (const item of this.data.items) {
          // Récupère les anciennes publications où l’option avait remplacé la liste.
          if (typeof item.commentsEnabled !== 'boolean') item.commentsEnabled = typeof item.comments === 'boolean' ? item.comments : true;
          if (!Array.isArray(item.comments)) item.comments = [];
        }
      }
    } catch { /* Le parcours reste disponible pour cette visite. */ }
  },
  persist() {
    try { localStorage.setItem(this.key,JSON.stringify(this.data)); }
    catch { window.Parcours.storageFailed = true; window.Parcours.storageStatus('Sauvegarde des partages indisponible · garde cette page ouverte.'); return false; }
    return window.Parcours.persist();
  },
  esc(value) { return window.Parcours.escape(value); },
  sourceItems() { return window.Parcours.state.saved || []; },
  cleanProgram(source) {
    const plan = source.sharedPlan || window.Programmes.snapshot(source);
    return window.Programmes.sessions(plan).map(session => ({name:session.name,exercises:session.exercises}));
  },
  readiness(source) {
    const sessions = this.cleanProgram(source);
    if (!sessions.length) return 'Ajoute au moins une séance au programme avant de le partager.';
    if (sessions.some(session => !session.exercises.length)) return 'Chaque séance doit contenir au moins un exercice.';
    if (sessions.some(session => session.exercises.some(item => !item.name))) return 'Vérifie que chaque exercice a un nom compréhensible.';
    return '';
  },
  render() {
    const p = window.Parcours;
    if (this.stage === 'list') return `${window.Parcours.storageFailed ? '<p class="draft-status">Sauvegarde indisponible · changements conservés pour cette visite</p>' : ''}${this.renderList()}`;
    if (this.stage === 'select') return this.renderSelect();
    if (this.stage === 'verify') return this.renderForm();
    if (this.stage === 'form') return this.renderForm();
    if (this.stage === 'preview') return this.renderPreview();
    if (this.stage === 'detail') return this.renderDetail();
    return `<h1 tabindex="-1">Partages</h1><button class="text-action" data-a="list">Retour aux partages</button>`;
  },
  renderList() {
    const items = this.data.items.map(item => `<article class="t4-card"><h2>${this.esc(item.title)}</h2><p>${this.esc(item.visibility === 'public' ? 'Communauté' : 'Mes contacts')} · ${this.esc(item.level)} · ${this.esc(item.status === 'published' ? 'Publié' : 'Retiré')}</p><button class="landing-button full" data-a="open" data-id="${item.id}">Gérer cette publication</button></article>`).join('');
    const drafts = Object.entries(window.Parcours.state.sharingDrafts || {}).map(([key,draft]) => `<button class="picker-result" data-a="resume-share" data-id="${key}"><span><strong>${this.esc(draft.fields.title || 'Partage en préparation')}</strong><small>Brouillon conservé · ${draft.editing ? 'Modification' : 'Nouveau partage'}</small></span><span>Reprendre</span></button>`).join('');
    return `<h1 tabindex="-1">Partages</h1><p class="landing-lead">Choisis un entraînement déjà préparé, vérifie ce qui sera visible, puis confirme avant publication.</p><button class="primary-action" data-a="start">Partager un programme</button>${drafts ? `<section class="landing-section"><h2>Brouillons</h2>${drafts}</section>` : ''}${items ? `<section class="landing-section"><h2>Mes publications</h2><div class="landing-stack">${items}</div></section>` : '<div class="empty-content"><h2>Aucune publication</h2><p>Tes programmes restent privés tant que tu ne confirmes pas leur partage.</p></div>'}`;
  },
  renderSelect() {
    const search = window.Parcours.state.ui.shareSearch || '';
    return `<button class="text-action" data-a="list">← Partages</button><h1 tabindex="-1">Choisir un programme</h1><p class="landing-lead">Choisis un contenu personnel. À compléter ouvre sa préparation sans perdre le partage.</p><label>Rechercher mes séances et programmes<input type="search" id="share-source-search" value="${this.esc(search)}"></label><div id="share-source-results" class="landing-stack">${this.sourceCards(search)}</div>`;
  },
  sourceCards(search) {
    const sources = this.sourceItems().filter(source => window.Ergonomie.normalize(source.name).includes(window.Ergonomie.normalize(search)));
    return sources.map(source => { const warning = this.readiness(source); return `<article class="t4-card"><h2>${this.esc(source.name)}</h2><p>${this.esc(source.organization || 'Séance seule')} · ${warning ? 'À compléter' : 'Prêt à partager'}</p><button class="landing-button full" data-a="choose" data-id="${source.id}">${warning ? 'Choisir et compléter' : 'Choisir ce programme'}</button></article>`; }).join('') || '<p>Aucun contenu avec ce nom. Crée une séance dans Mes entraînements ou modifie la recherche.</p><button class="landing-button" data-a="mine">Mes entraînements</button>';
  },
  rememberDraft() {
    window.Parcours.state.sharingDrafts ||= {};
    window.Parcours.state.sharingDrafts[this.draftKey()] = {sourceId:this.source.id,editing:this.editing,activeId:this.activeId,fields:{...this.draft}};
    return window.Parcours.persist();
  },
  prepare(source) {
    if (!source) return;
    this.source = source; this.editing = false; this.activeId = null;
    this.draft = window.Parcours.state.sharingDrafts?.[`new:${source.id}`]?.fields || {title:source.name,level:source.level || window.Parcours.state.profile.level || '',zone:source.group || '',description:source.description || '',visibility:'public',commentsEnabled:true,feedback:false};
    this.rememberDraft(); this.go('form');
  },
  completeSource() {
    const source = this.sourceItems().find(item => item.id === this.source?.id);
    if (!source || this.editing) return;
    this.rememberDraft(); window.Entrainements.openDraft(source);
  },
  presentationErrors(fields) {
    const errors = {};
    if (!fields.title?.trim() || fields.title.length > 100) errors.title = 'Donne un titre de 1 à 100 caractères.';
    if (!['Débutant','Intermédiaire','Avancé'].includes(fields.level)) errors.level = 'Choisis le niveau de ce programme.';
    if ((fields.description || '').length > 500) errors.description = 'La description peut contenir au maximum 500 caractères, ou rester vide.';
    return errors;
  },
  renderForm() {
    const d = this.draft || {}, warning = this.readiness(this.source);
    const content = window.Programmes.scheduleSummary(this.source.sharedPlan || window.Programmes.snapshot(this.source));
    return `<button class="text-action" data-a="select">← Choisir le programme</button><p class="form-stepper" aria-label="Étape 2 sur 3">1. Contenu <span aria-hidden="true">→</span> <strong>2. Présentation</strong> <span aria-hidden="true">→</span> 3. Confirmation</p><h1 tabindex="-1">${this.editing ? 'Modifier la publication' : 'Nouveau partage'}</h1><p class="draft-status" role="status" id="sharing-draft-status">Brouillon · rien n’est publié avant confirmation</p><section class="sharing-content"><h2>${this.esc(this.source.name)}</h2>${content}<p>Résultats réels, notes personnelles et identifiants restent privés.</p>${warning ? `<p class="error" role="alert">${this.esc(warning)}</p>${!this.editing && this.sourceItems().some(item => item.id === this.source.id) ? '<button type="button" class="landing-button" data-a="complete-source">Compléter ce contenu puis revenir au partage</button>' : ''}` : ''}</section><p class="landing-lead" id="sharing-audience-summary">Ces informations accompagnent le programme dans ${d.visibility === 'contacts' ? 'tes contacts' : 'la communauté'}.</p><form id="t4-form" class="create-form" novalidate><label for="t4-title">Titre<input id="t4-title" name="title" maxlength="100" required aria-describedby="t4-title-error" value="${this.esc(d.title ?? this.source.name)}"><small class="field-count" data-count-for="t4-title">${String(d.title ?? this.source.name).length}/100</small></label><p id="t4-title-error" class="error" role="alert"></p><label for="t4-level">Niveau<select id="t4-level" name="level" required aria-describedby="t4-level-error"><option value="">Choisir un niveau</option>${['Débutant','Intermédiaire','Avancé'].map(level => `<option ${d.level === level ? 'selected' : ''}>${level}</option>`).join('')}</select></label><p id="t4-level-error" class="error" role="alert"></p><label for="t4-zone">Zone ciblée<select id="t4-zone" name="zone"><option value="">Non précisée</option>${['Corps entier','Haut du corps','Jambes','Pectoraux','Dos','Épaules','Bras','Abdominaux'].map(zone => `<option ${d.zone === zone ? 'selected' : ''}>${zone}</option>`).join('')}</select></label><details class="advanced-options"><summary>Description et commentaires <span>(facultatif)</span></summary><label for="t4-description">Description <span>(objectif et public visé)</span><textarea id="t4-description" name="description" maxlength="500" aria-describedby="t4-description-error">${this.esc(d.description || '')}</textarea><small class="field-count" data-count-for="t4-description">${String(d.description || '').length}/500</small></label><p id="t4-description-error" class="error" role="alert"></p><label class="t4-check"><input type="checkbox" name="feedback" ${d.feedback ? 'checked' : ''}>Demander des conseils</label><label class="t4-check"><input type="checkbox" name="commentsAllowed" ${d.commentsEnabled !== false ? 'checked' : ''}>Autoriser les commentaires</label></details><fieldset class="t4-fieldset"><legend>Audience</legend><label><input type="radio" name="visibility" value="public" ${d.visibility === 'contacts' ? '' : 'checked'}> Communauté</label><label><input type="radio" name="visibility" value="contacts" ${d.visibility === 'contacts' ? 'checked' : ''}> Mes contacts</label></fieldset><p id="t4-form-error" class="t4-error" role="alert"></p><button class="primary-action landing-section" type="submit" ${warning ? 'disabled' : ''}>Continuer vers l’aperçu →</button><button type="button" class="text-action" id="discard-share-draft">Abandonner ce brouillon</button></form>`;
  },
  renderPreview() {
    const d = this.draft;
    return `<button class="text-action" data-a="form">← Modifier la présentation</button><p class="form-stepper" aria-label="Étape 3 sur 3">1. Contenu → 2. Présentation → <strong>3. Confirmation</strong></p><h1 tabindex="-1">${this.editing ? 'Vérifier les modifications' : 'Aperçu avant publication'}</h1><p class="landing-lead">Voici ce que ${d.visibility === 'public' ? 'la communauté' : 'tes contacts'} verra.</p><article class="t4-preview"><p class="landing-tag">${this.esc(d.level)}${d.zone ? ` · ${this.esc(d.zone)}` : ''}</p><h2>${this.esc(d.title)}</h2><p>${this.esc(d.description)}</p>${d.feedback ? '<p><strong>Demande de conseils</strong></p>' : ''}<p>${d.commentsEnabled ? 'Commentaires autorisés' : 'Commentaires fermés'}</p><h3>${this.esc(this.source.name)}</h3>${window.Programmes.scheduleSummary(this.source.sharedPlan || window.Programmes.snapshot(this.source))}<p class="t4-privacy-note">Les résultats réels et les notes personnelles ne sont pas inclus.</p></article><div class="program-publication-actions"><p>Audience : <strong>${d.visibility === 'public' ? 'Communauté' : 'Mes contacts'}</strong>. ${this.editing ? 'Cette action met à jour la présentation publiée.' : 'Cette action publie le contenu présenté ci-dessus.'}</p><button class="primary-action landing-section" data-a="publish">${this.editing ? `Mettre à jour pour ${d.visibility === 'public' ? 'la communauté' : 'mes contacts'}` : d.visibility === 'public' ? 'Publier dans la communauté' : 'Partager avec mes contacts'}</button></div>`;
  },
  renderDetail() {
    const item = this.data.items.find(entry => entry.id === this.activeId);
    if (!item) return '<h1 tabindex="-1">Publication introuvable</h1><button data-a="list" class="landing-button">Retour</button>';
    const program = item.plan ? window.Programmes.scheduleSummary(item.plan) : window.Programmes.previewSessions(item.program || []);
    const comments = item.comments.map((comment,index) => `<article class="t4-comment"><p><strong>${this.esc(comment.author)}</strong></p><p>${this.esc(comment.text)}</p>${comment.reply ? `<p class="t4-reply"><strong>Ta réponse :</strong> ${this.esc(comment.reply)}</p>` : `<form data-reply="${index}" class="t4-reply-form"><label>Répondre<input name="reply" maxlength="300" required></label><button class="landing-button" type="submit">Envoyer la réponse</button></form>`}</article>`).join('');
    const sourceExists = this.sourceItems().some(source => source.id === item.sourceId);
    return `<button class="text-action" data-a="list">← Mes partages</button><h1 tabindex="-1">Gérer la publication</h1><article class="t4-card"><h2>${this.esc(item.title)}</h2><p>${this.esc(item.visibility === 'public' ? 'Communauté' : 'Mes contacts')} · ${item.status === 'published' ? 'Publication active' : 'Publication retirée'}</p><p>${this.esc(item.description)}</p><p>Commentaires ${item.commentsEnabled ? 'autorisés' : 'fermés'} · ${item.feedback ? 'Conseils demandés' : 'Pas de demande de conseils'}</p><h3>${this.esc(item.sourceName)}</h3>${program}<p class="t4-privacy-note">Aucun résultat réel ni note personnelle n’est inclus.</p></article>${item.visibility === 'public' && item.status === 'published' ? '<button class="landing-button full landing-section" data-a="feed">Voir dans le fil d’actualité</button>' : ''}<section class="landing-section"><h2>Retours</h2>${comments || '<p class="empty-content">Aucun commentaire reçu. Les retours apparaîtront ici.</p>'}${item.commentsEnabled && item.status === 'published' ? '<button class="landing-button landing-section" data-a="demo-comment">Simuler un commentaire reçu</button>' : ''}</section><div class="t4-actions"><button class="landing-button" data-a="edit">Modifier la présentation</button>${item.status === 'published' && sourceExists ? '<button class="landing-button" data-a="refresh-program">Actualiser depuis Mes entraînements</button>' : ''}${item.status === 'published' ? '<button class="landing-button" data-a="withdraw">Retirer la publication</button>' : '<button class="landing-button" data-a="republish">Republier</button>'}</div>`;
  },
  bind() {
    const page = document.querySelector('#landing-page');
    const advanced = page.querySelector('.advanced-options');
    if (advanced) {
      const description = advanced.querySelector('#t4-description');
      if (description && (description.value || this.draft?.feedback || this.draft?.commentsEnabled === false)) advanced.open = true;
    }
    page.onclick = event => {
      const button = event.target.closest('[data-a]');
      if (!button) return;
      const action = button.dataset.a;
      if (action === 'start') { this.editing = false; this.source = null; this.draft = null; this.activeId = null; this.go('select'); }
      else if (action === 'list') this.go('list');
      else if (action === 'select') this.go('select');
      else if (action === 'mine') window.Parcours.route('library');
      else if (action === 'choose') this.prepare(this.sourceItems().find(item => item.id === button.dataset.id));
      else if (action === 'complete-source') this.completeSource();
      else if (action === 'verify') this.go('form');
      else if (action === 'form') this.go('form');
      else if (action === 'publish') this.publish();
      else if (action === 'open') { this.activeId = button.dataset.id; this.go('detail'); }
      else if (action === 'feed') { const item = this.active(); if (item?.visibility === 'public' && item.status === 'published') { window.Parcours.state.source = 'community'; window.Parcours.state.ui.favoritesOnly = false; window.Parcours.route('discover'); } }
      else if (action === 'edit') { const item = this.active(); if (item) { this.source = this.publicationSource(item); this.editing = true; this.draft = window.Parcours.state.sharingDrafts?.[`edit:${item.id}`]?.fields || this.presentation(item); this.go('form'); } }
      else if (action === 'resume-share') {
        const stored = window.Parcours.state.sharingDrafts[button.dataset.id];
        if (stored) { this.editing = stored.editing; this.activeId = stored.activeId; this.source = stored.editing ? this.publicationSource(this.active()) : this.sourceItems().find(item => item.id === stored.sourceId); this.draft = stored.fields; if (this.source) this.go('form'); }
      }
      else if (action === 'refresh-program') { const item = this.active(), source = this.sourceItems().find(entry => entry.id === item?.sourceId); if (item && source) window.Ergonomie.confirm('Actualiser le contenu partagé ?', 'Le contenu publié sera remplacé par la version enregistrée dans Mes entraînements.',() => { const warning = this.readiness(source); if (warning) { window.Parcours.notify(warning); return; } item.sourceName = source.name; item.program = this.cleanProgram(source); item.plan = window.Programmes.snapshot(source); this.persist(); this.go('detail'); },'Actualiser la publication'); }
      else if (action === 'withdraw') { const item = this.active(); if (item) window.Ergonomie.confirm('Retirer la publication ?',item.title,() => { item.status = 'withdrawn'; this.persist(); this.go('detail'); },'Retirer'); }
      else if (action === 'republish') { const item = this.active(); if (item) window.Ergonomie.confirm('Republier ?',`Audience : ${item.visibility === 'public' ? 'Communauté' : 'Mes contacts'}`,() => { item.status = 'published'; this.persist(); this.go('detail'); },item.visibility === 'public' ? 'Republier dans la communauté' : 'Republier avec mes contacts'); }
      else if (action === 'demo-comment') { const item = this.active(); if (item) { item.comments.push({author:'Camille · compte fictif',text:'La structure est claire. Comment as-tu choisi cette répartition ?'}); this.persist(); this.go('detail'); } }
    };
    const search = document.querySelector('#share-source-search'); if (search) search.oninput = () => { window.Parcours.state.ui.shareSearch = search.value; document.querySelector('#share-source-results').innerHTML = this.sourceCards(search.value); window.Parcours.persist(); };
    const form = document.querySelector('#t4-form');
    if (form) {
      const remember = () => {
        this.draft = this.presentation({...Object.fromEntries(new FormData(form)),feedback:form.elements.feedback.checked,commentsEnabled:form.elements.commentsAllowed.checked});
        const saved = this.rememberDraft(); document.querySelector('#sharing-draft-status').textContent = saved ? 'Brouillon conservé · rien n’est publié' : 'Sauvegarde indisponible';
        document.querySelector('#sharing-audience-summary').textContent = `Ces informations accompagnent le programme dans ${this.draft.visibility === 'contacts' ? 'tes contacts' : 'la communauté'}.`;
      };
      const showError = name => {
        const input = form.elements[name], error = this.presentationErrors(this.draft)[name] || '';
        document.querySelector(`#t4-${name}-error`).textContent = error; input.setAttribute('aria-invalid',String(!!error)); return !!error;
      };
      form.oninput = event => { remember(); if (['title','level','description'].includes(event.target.name) && event.target.getAttribute('aria-invalid') === 'true') showError(event.target.name); document.querySelector('#t4-form-error').textContent = ''; };
      form.querySelectorAll('[data-count-for]').forEach(counter => { const field = form.querySelector(`#${counter.dataset.countFor}`); if (field) field.addEventListener('input', () => { counter.textContent = `${field.value.length}/${field.maxLength}`; }); });
      form.onchange = remember;
      for (const name of ['title','level','description']) form.elements[name].onblur = () => { remember(); showError(name); };
      document.querySelector('#discard-share-draft').onclick = () => window.Ergonomie.confirm('Abandonner ce brouillon ?', 'La publication existante reste conservée.',() => { delete window.Parcours.state.sharingDrafts[this.draftKey()]; this.draft = null; this.editing = false; this.go('list'); },'Abandonner');
      form.onsubmit = event => {
        event.preventDefault(); remember();
        const errors = this.presentationErrors(this.draft); for (const name of ['title','level','description']) showError(name);
        const first = Object.keys(errors)[0]; if (first) { const details = form.elements[first].closest('details'); if (details) details.open = true; form.elements[first].focus(); return; }
        this.go('preview');
      };
    }
    page.querySelectorAll('[data-reply]').forEach(form => form.onsubmit = event => { event.preventDefault(); const item = this.active(); const comment = item?.comments[Number(form.dataset.reply)]; const reply = new FormData(form).get('reply').trim(); if (comment && reply) { comment.reply = reply; this.persist(); this.go('detail'); } });
  },
  draftKey() { return this.editing ? `edit:${this.activeId}` : `new:${this.source.id}`; },
  presentation(fields) { return {title:fields.title || '',level:fields.level || '',zone:fields.zone || '',description:fields.description || '',visibility:fields.visibility || 'public',feedback:!!fields.feedback,commentsEnabled:fields.commentsEnabled !== false}; },
  publicationSource(item) { return item ? {id:item.sourceId,name:item.sourceName,sharedPlan:item.plan,organization:'Archive',days:(item.program || []).map(session => ({type:'session',name:session.name,exercises:session.exercises}))} : null; },
  active() { return this.data.items.find(item => item.id === this.activeId); },
  publish() {
    const p = window.Parcours;
    if (this.stage !== 'preview' || !this.source || !this.draft) { p.notify('Vérifie l’aperçu avant de confirmer le partage.'); return; }
    if (this.readiness(this.source) || Object.keys(this.presentationErrors(this.draft)).length) { p.notify('Complète les informations signalées avant publication.'); this.go('form'); return; }
    if (this.editing) { this.saveEdit(); return; }
    const draftKey = this.draftKey(), stored = p.state.sharingDrafts?.[draftKey];
    const record = {id:crypto.randomUUID(),sourceId:this.source.id,sourceName:this.source.name,program:this.cleanProgram(this.source),plan:window.Programmes.snapshot(this.source),...this.draft,status:'published',comments:[],createdAt:new Date().toISOString()};
    this.data.items.unshift(record); delete p.state.sharingDrafts?.[draftKey];
    if (!this.persist()) {
      this.data.items = this.data.items.filter(item => item !== record);
      p.state.sharingDrafts ||= {}; p.state.sharingDrafts[draftKey] = stored || {sourceId:this.source.id,editing:false,activeId:null,fields:{...this.draft}};
      this.persist();
      p.notify('Publication non confirmée · brouillon conservé. Réessaie après avoir rétabli la sauvegarde.'); return;
    }
    this.editing = false; this.activeId = record.id; this.go('detail'); p.notify('Publication confirmée dans cette démonstration.');
  },
  saveEdit() {
    const p = window.Parcours, item = this.active();
    if (!item) return;
    const before = structuredClone(item), draftKey = this.draftKey(), stored = p.state.sharingDrafts?.[draftKey];
    Object.assign(item,this.presentation(this.draft)); delete p.state.sharingDrafts?.[draftKey];
    if (!this.persist()) {
      Object.assign(item,before); p.state.sharingDrafts ||= {}; p.state.sharingDrafts[draftKey] = stored || {sourceId:this.source.id,editing:true,activeId:this.activeId,fields:{...this.draft}};
      this.persist(); p.notify('Modification non confirmée · brouillon conservé. Réessaie après avoir rétabli la sauvegarde.'); return;
    }
    this.editing = false; this.go('detail'); p.notify('Modifications confirmées');
  },
  go(stage) { this.stage = stage; window.Parcours.route('sharing'); },
};
window.Partages.restore();
