# Problème — V1

**Auteur :** Matthieu  
**Reviewer :** toute l'équipe  
**Doc :** [reunions/2026-09-11-ideation.md](../../reunions/2026-09-11-ideation.md)

## Contexte d'usage

Une personne qui pratique la musculation organise ses séances autour d'un programme (choix des exercices, séries, répétitions, charges) qu'elle doit suivre dans la durée pour progresser. L’hypothèse de cadrage est qu’une partie des pratiquants suit ses séances sur papier, dans un tableur excel, ou dans des applications généralistes peu adaptées, ce qui rend difficile de :

- préparer une séance à l'avance en s'appuyant sur ce qui a été fait précédemment ;
- suivre, pendant la séance, ce qui a réellement été réalisé par rapport à ce qui était prévu ;
- garder une trace fiable de sa progression (records, charges maximales) dans le temps ;
- situer les séances passées et à venir dans un calendrier ou un programme structuré ;
- noter un ressenti (fatigue, difficulté, douleur) sur une séance ou un exercice précis.

L'application visée se limite au suivi de l'entraînement de musculation.

## Problème

Nous faisons l’hypothèse que les outils utilisés par les profils visés ne couvrent pas simplement à la fois la préparation d'un programme d'entraînement structuré dans le temps (blocs de plusieurs mois, séances répétées sur un cycle, ex. 7 jours), le suivi en séance de sa réalisation, et la visualisation de la progression (PR/max, historique), sans complexité excessive ni fonctionnalités hors sujet (diététique, réseau social, etc.).

Les difficultés que le projet cherche à réduire sont les suivantes (hypothèses à confronter à des usages réels) :

- perte de temps à préparer ou noter ses séances dans des outils non prévus pour ça
- difficulté à savoir si une séance a été suivie comme prévu et pourquoi (charge trop lourde, fatigue, etc.)
- absence de vue claire sur la progression réelle, ce qui limite la motivation et l'ajustement du programme
- programmes et exercices non réutilisables ni partageables facilement d'une séance ou d'un utilisateur à l'autre

## Objectifs utilisateurs

- Pouvoir préparer une séance à l'avance : choisir des exercices, définir séries, répétitions et charges.
- Pouvoir organiser ses séances dans un programme structuré dans le temps (bloc, ex. 6 mois) composé de cycles répétés (sous-bloc, ex. 7 jours).
- Pouvoir suivre, pendant ou après la séance, ce qui a été réalisé par rapport à ce qui était prévu.
- Pouvoir enregistrer ses records/maximums et visualiser sa progression sous forme de graphique.
- Pouvoir situer ses séances dans un calendrier.
- Pouvoir noter un ressenti global sur une séance, ou ciblé sur un exercice précis.
- Pouvoir personnaliser la liste des exercices : afficher, créer, ou s'appuyer sur des exercices/séances/blocs prédéfinis.
- Pouvoir archiver ou supprimer un cycle/programme devenu obsolète.
- Pouvoir, à terme, partager un entraînement avec d'autres utilisateurs.

## Objectifs du projet

Voir l’[objectif du projet](../../README.md#objectif) : construire et justifier une proposition d’IHM adaptée aux besoins utilisateurs, avec une démarche de conception documentée.

## Contraintes et hypothèses

- Cible : application mobile, dédiée uniquement au suivi de l'entraînement de musculation (le volet diététique est explicitement exclu).
- Hypothèse : les utilisateurs ont des niveaux d'expérience très différents (débutant, avancé et confirmé), (cf. personas dans `docs/02-utilisateurs-personas/`).
- Hypothèse : la modification d'une séance doit pouvoir, au choix de l'utilisateur, se répercuter ou non sur les séances suivantes du même cycle.



## Statut des preuves — revue du 4 novembre 2026

Le cadrage et les personas sont des choix de conception validés par l’équipe. L’[analyse concurrentielle](../../research/analyse-concurrence/synthese-concurrence.md) documente des interfaces et des avis, mais ne démontre ni une absence générale d’outil adapté ni la fréquence de ces difficultés dans notre population. Aucun corpus d’entretiens ou d’observations du public cible n’est archivé ici. Le [protocole utilisateur](../07-evaluation/protocole-utilisateur.md) doit mettre à l’épreuve ces hypothèses ; le partage retenu dans T4 porte sur des programmes, pas sur un réseau social généraliste.
